import React from "react";

const live = () => {

    return (
        
        <div>실시간 현황 페이지
        </div>
    )
}

export default live;